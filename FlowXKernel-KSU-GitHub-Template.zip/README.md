# FlowXKernel-KSU for Redmi Note 8 (ginkgo)

## Features:
- KernelSU (latest)
- SUSFS Manual Hook Mode
- zRAM support
- I/O Scheduler: maple, bfq, sio, zen
- CPU Governors: schedutil, blu_active, smartassV2
- No splashscreen
